<?php

header('Location: /');
